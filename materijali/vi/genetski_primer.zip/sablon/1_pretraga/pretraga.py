#! /usr/bin/env python
# -*- coding: utf-8 -*-

from collections import deque

class Graph:

  def __init__ (self, start_state):
    self.marked = {}

  def reset_marks(self):
    self.marked = {}

  def get_neighbors(self, current_state):
    neighbors = []

    # Studentski kod

    return list(zip(neighbors, [1 for i in range(len(neighbors))]))


  def BFS(self, start, stop):

  	# Studentski kod

          for (w, weight) in self.get_neighbors(v):
          	# Studentski kod

  
def main():
  start_state = 'BBBB_CCCC'
  end_state = 'CCCC_BBBB'

  game = Graph(start_state)

  print(game.BFS(start_state, end_state))
  
if __name__ == "__main__":
  main()
