#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys


level = [1, 1, 1, 0, 1, 0, 1, 0, 1, 1]

def make_a_run(chromosome, should_log=False):
    global level
    fitness = 0

    IDI_DESNO = 1
    SKOCI = 0
    RUPA = 0
    ZEMLJA = 1

    if len(chromosome) != len(level):
        sys.exit("Duzina hromozoma mora biti {}".format(len(level)))

    for i, potez in enumerate(chromosome):
        # Ako je igrac naleteo na rupu a nije skocio, zaustavljamo sa daljom
        # proverom i vracamo fitness koji je do sada izracunat.
        if level[i] == RUPA and potez == IDI_DESNO:
            if should_log: print("{}: Naleteo na rupu i nije skocio, kraj igre.".format(i))
            return fitness
        # Ako je naleteo na rupu i skocio, povecamo fitness
        elif level[i] == RUPA and potez == SKOCI:
            if should_log: print("{}: Preskocio rupu".format(i))
            fitness += 1
        # Ako je na zemlji i idi desno, povecamo fitness
        elif level[i] == ZEMLJA and potez == IDI_DESNO:
            if should_log: print("{}: Pomerio se udesno na zemlji".format(i))
            fitness += 1
        elif level[i] == ZEMLJA and potez == SKOCI:
            if should_log: print("{}: Skocio bez potrebe".format(i))
    if should_log: print("Presao nivo!")

    return fitness

def main():
    # Nivo
    # ---_-_-_--
    fitness = make_a_run([1, 1, 1, 0, 1, 0, 1, 1, 1, 1], True)
    print("Fitness: {}".format(fitness))

if __name__ == "__main__":
    main()
