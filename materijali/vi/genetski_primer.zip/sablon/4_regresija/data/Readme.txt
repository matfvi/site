Features consist of hourly average ambient variables 
- Temperature (T) in the range 1.81°C and 37.11°C,
- Ambient Pressure (AP) in the range 992.89-1033.30 milibar,
- Relative Humidity (RH) in the range 25.56% to 100.16%
- Exhaust Vacuum (V) in teh range 25.36-81.56 cm Hg
- Net hourly electrical energy output (EP) 420.26-495.76 MW

Atributi:
- Temperatura (Temperature - T) u opsegu 1.81°C and 37.11°C
- Atmosferski pritisak (Ambient Pressure - AP) u opsegu 992.89-1033.30 milibara
- Relativna vlaznost (Relative Humidity RH) u opsegu 25.56% to 100.16%
- Izduvni vakuum (Exhaust Vacuum - V) u opsegu 25.36-81.56 cm Hg
- Potrosnja elektricne energije po satu (Net hourly electrical energy output - EP) 420.26-495.76 MW

Podaci su sakupljeni sa senzora koji se nalazi u okviru fabrike i vrse ocitavanje svake sekunde.
